/*
 * AddAssessmentForm.java 
 *
 * presents the form for assessment 
 */
package prs;

import java.util.Scanner;

/**
 *
 * @author elau
 */
public class AddAssessmentForm {

    private static final int MIN = 0;
    private static final int MAX = 5;
    private static final int MIN_ID_LENGTH = 7;
    private static final int MAX_ID_LENGTH = 10;

    private static final String ERR_STUDE_ID = "Please enter at least " + MIN_ID_LENGTH + "characters and at most " + MAX_ID_LENGTH + " characters for student id!";
    private static final String ERR_INT_VALUE = "Please enter an integer from 0 to 5";

    private boolean isIdLengthValid(String str) {
        int length = str.length();
        if (length >= MIN_ID_LENGTH && length <= MAX_ID_LENGTH) {
            return true;
        } else {
            return false;
        }
    }

    private boolean isValueInRange(int value) {
        if (value >= MIN && value <= MAX) {
            return true;
        } else {
            return false;
        }
    }
    
    public String getStudeId(Scanner scanner, String prompt) {
        
        String sId = null;
        boolean validInput = false;
        
        while (!validInput) {
            System.out.print(prompt);

            sId = scanner.nextLine();
            if (!isIdLengthValid(sId)) {
                System.err.println(ERR_STUDE_ID);
                validInput = false;
            } else {
                validInput = true;
            }
        }
        return sId;
    }
    
    public int getAssessmentValue(Scanner scanner, String prompt) {
        int value = -1;
        boolean validInput = false;
        while (!validInput) {
            System.out.print(prompt);
            String tmpStr = scanner.nextLine();
            try {
                value = Integer.parseInt(tmpStr);
                if (!isValueInRange(value)) {
                    System.err.println(ERR_INT_VALUE);
                } else {
                    validInput = true;
                }
            } catch (NumberFormatException ex) {
                System.err.println(ERR_INT_VALUE);
            }
        }
        return value;
    }

    public Assessment addNewAssessment() {
        Scanner scanner = new Scanner(System.in);

        String studeId = getStudeId(scanner, "Enter your student Id (xxxxxxx): ");

        String teamMmbrId = getStudeId(scanner, "Enter your team member's student Id (xxxxxxx): ");

        System.out.println("Enter your assessment for " + teamMmbrId + " below: ");

        int wrkQnty = getAssessmentValue(scanner, "Enter the Work Quantity (0 - 5): ");

        int wrkQlty = getAssessmentValue(scanner, "Enter the Work Quality (0 - 5): ");
        
        // others are omitted
        
        // close input
        scanner.close();

        // create an assessment record
        Assessment assessment = new Assessment(studeId, teamMmbrId, wrkQnty, wrkQlty, 0, 0, 0, 0, 0, 0, 0, 0);

        return assessment;
    }

}
