/*
 * PRS_AddNewAssessment.java
 *
 * peer review system
 */
package prs;

/**
 *
 * @author elau
 */
public class PRS_AddNewAssessment {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        AddAssessmentForm form = new AddAssessmentForm();
        
        Assessment assessment = form.addNewAssessment();
        
        // display data for verification
        assessment.display();
        
        // save assessment record to database
        assessment.saveData2DB();
    }
}
