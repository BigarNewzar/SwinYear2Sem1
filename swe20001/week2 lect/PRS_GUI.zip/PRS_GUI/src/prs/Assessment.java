/*
 * Assessment.java
 *
 * holds assessment record
 */
package prs;

/**
 *
 * @author elau
 */
public class Assessment {

    private String assessorId;
    private String assesseeId;

    private int wrkQnty;        // Quantity of Work
    private int wrkQlty;        // Quality of Work
    private int cmmSkill;       // Communication Skills
    private int initiative;     // Inititative
    private int efficiency;     // Efficiency
    private int personal;       // Personal Relations
    private int grpMtg;         // Group Meeting Attendance
    private int attitude;       // Attitude and Enthusiasm
    private int effort;         // Effort
    private int dependability;  // Dependability

    public Assessment(String assessorId, String assesseeId, int wrkQnty, int wrkQlty, int cmmSkill, int initiative, int efficiency, int personal, int grpMtg, int attitude, int effort, int dependability) {
        this.assessorId = assessorId;
        this.assesseeId = assesseeId;
        this.wrkQnty = wrkQnty;
        this.wrkQlty = wrkQlty;
        this.cmmSkill = cmmSkill;
        this.initiative = initiative;
        this.efficiency = efficiency;
        this.personal = personal;
        this.grpMtg = grpMtg;
        this.attitude = attitude;
        this.effort = effort;
        this.dependability = dependability;
    }

    public String getAssessorId() {
        return assessorId;
    }

    public void setAssessorId(String assessorId) {
        this.assessorId = assessorId;
    }

    public String getAssesseeId() {
        return assesseeId;
    }

    public void setAssesseeId(String assesseeId) {
        this.assesseeId = assesseeId;
    }

    public int getWrkQnty() {
        return wrkQnty;
    }

    public void setWrkQnty(int wrkQnty) {
        this.wrkQnty = wrkQnty;
    }

    public int getWrkQlty() {
        return wrkQlty;
    }

    public void setWrkQlty(int wrkQlty) {
        this.wrkQlty = wrkQlty;
    }

    public int getCmmSkill() {
        return cmmSkill;
    }

    public void setCmmSkill(int cmmSkill) {
        this.cmmSkill = cmmSkill;
    }

    public int getInitiative() {
        return initiative;
    }

    public void setInitiative(int initiative) {
        this.initiative = initiative;
    }

    public int getEfficiency() {
        return efficiency;
    }

    public void setEfficiency(int efficiency) {
        this.efficiency = efficiency;
    }

    public int getPersonal() {
        return personal;
    }

    public void setPersonal(int personal) {
        this.personal = personal;
    }

    public int getGrpMtg() {
        return grpMtg;
    }

    public void setGrpMtg(int grpMtg) {
        this.grpMtg = grpMtg;
    }

    public int getAttitude() {
        return attitude;
    }

    public void setAttitude(int attitude) {
        this.attitude = attitude;
    }

    public int getEffort() {
        return effort;
    }

    public void setEffort(int effort) {
        this.effort = effort;
    }

    public int getDependability() {
        return dependability;
    }

    public void setDependability(int dependability) {
        this.dependability = dependability;
    }

    public void display() {
        System.out.println("Student Id: " + assessorId);
        System.out.println("Team Member Id: " + assesseeId);
        System.out.println("Work Quantity: " + wrkQnty);
        System.out.println("Work Quality: " + wrkQlty);
        System.out.println("Communication Skills: " + cmmSkill);
        System.out.println("Initiative: " + initiative);
        System.out.println("Efficiency: " + efficiency);
        System.out.println("Personal Relations: " + personal);
        System.out.println("Group Meeting Attendance: " + grpMtg);
        System.out.println("Attitude and Enthusiasm: " + attitude);
        System.out.println("Effort: " + effort);
        System.out.println("Dependability: " + dependability);
    }
    
    public void saveData2DB() {
        // stub module - not yet implemented
        System.out.println("Saving the assessment data to database!");
        
        // connecting to database

        // issue embedded SQL

        // check responses ...
        
    }
}
