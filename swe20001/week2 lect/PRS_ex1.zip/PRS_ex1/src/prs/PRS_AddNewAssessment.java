/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prs;

import java.util.Scanner;

/**
 *
 * @author elau
 */
public class PRS_AddNewAssessment {

    private static final int MIN = 0;
    private static final int MAX = 5;
    private static final int MIN_ID_LENGTH = 7;
    private static final int MAX_ID_LENGTH = 10;

    private static final String ERR_STUDE_ID = "Please enter at least " + MIN_ID_LENGTH + "characters and at most " + MAX_ID_LENGTH + " characters for student id!";
    private static final String ERR_INT_VALUE = "Please enter an integer from 0 to 5";

    private static boolean checkIdLength(String str) {
        int length = str.length();
        if (length >= MIN_ID_LENGTH && length <= MAX_ID_LENGTH) {
            return true;
        } else {
            return false;
        }
    }

    private static boolean checkValueRange(int value) {
        if (value >= MIN && value <= MAX) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String studeId = null;
        boolean validInput = false;
        while (!validInput) {
            System.out.print("Enter your student Id (xxxxxxx): ");
            studeId = scanner.nextLine();
            if (!checkIdLength(studeId)) {
                System.err.println(ERR_STUDE_ID);
                validInput = false;
            } else {
                validInput = true;
            }
        }

        String teamMmbrId = null;
        validInput = false;
        while (!validInput) {
            System.out.print("Enter your team member's student Id (xxxxxxx): ");
            teamMmbrId = scanner.nextLine();
            if (!checkIdLength(teamMmbrId)) {
                System.err.println(ERR_STUDE_ID);
                validInput = false;
            } else {
                validInput = true;
            }
        }

        System.out.println("Enter your assessment for " + teamMmbrId + " below: ");

        int wrkQnty = -1;
        validInput = false;
        while (!validInput) {
            System.out.print("Enter the Work Quantity (0 - 5): ");
            String tmpStr = scanner.nextLine();
            wrkQnty = Integer.parseInt(tmpStr);
            if (!checkValueRange(wrkQnty)) {
                System.err.println(ERR_INT_VALUE);
                validInput = false;
            } else {
                validInput = true;
            }
        }

        int wrkQlty = -1;
        validInput = false;
        while (!validInput) {
            System.out.print("Enter the Work Quality (0 - 5): ");
            String tmpStr = scanner.nextLine();
            wrkQlty = Integer.parseInt(tmpStr);
            if (!checkValueRange(wrkQlty)) {
                System.err.println(ERR_INT_VALUE);
                validInput = false;
            } else {
                validInput = true;
            }
        } 

        // other inputs are omitted
        // assessment record - information
        // display assessment information 
        System.out.println("Student Id: " + studeId);
        System.out.println("Team Member Id: " + teamMmbrId);
        System.out.println("Work Quantity: " + wrkQnty);
        System.out.println("Work Quality: " + wrkQlty);
//        System.out.println("Communication Skills: " + cmmSkill);
//        System.out.println("Initiative: " + initiative);
//        System.out.println("Efficiency: " + efficiency);
//        System.out.println("Personal Relations: " + personal);
//        System.out.println("Group Meeting Attendance: " + grpMtg);
//        System.out.println("Attitude and Enthusiasm: " + attitude);
//        System.out.println("Effort: " + effort);
//        System.out.println("Dependability: " + dependability);
    }

}
